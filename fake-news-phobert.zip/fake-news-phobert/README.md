# Phát hiện tin giả tiếng Việt với PhoBERT (Đề tài 9)

## Cài đặt
```bash
pip install -r requirements-nlp.txt
```

## Dữ liệu
Đặt file CSV vào `data/news.csv` với 2 cột `text`, `label` (0/1). Nếu tên cột khác, dùng `--text-col`, `--label-col`.
**Làm sạch dữ liệu trước** (audit → thiếu → outlier → nhất quán → trùng lặp → kiểm tra lại).
`data.py` tự bỏ trùng, chia phân tầng 70/15/15 và tách từ bằng underthesea (cache vào `data/news.seg.csv`).

## Chạy
```bash
cd src
python train.py --csv ../data/news.csv --model vinai/phobert-base         # fine-tune PhoBERT
python baselines.py --csv ../data/news.csv --seeds 42 43 44               # SVM, BiLSTM, XLM-R
python tune.py --csv ../data/news.csv --trials 15                         # Optuna
python compare.py                                                         # bảng so sánh
```
Chạy các lệnh từ trong `src/` (kết quả ghi vào `results/`, checkpoint vào `models/`).
Nếu chạy từ thư mục gốc, đổi đường dẫn tương ứng.

## Lưu ý
- PhoBERT: văn bản đã tách từ, tối đa 256 token. XLM-R: dùng văn bản thô.
- Chọn mô hình theo F1 trên val; test chỉ đánh giá một lần.
- GPU yếu: `--max-len 128 --batch-size 16`.
