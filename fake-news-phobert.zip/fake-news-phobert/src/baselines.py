"""Các mô hình baseline: TF-IDF+SVM, BiLSTM, XLM-RoBERTa. Ghi kết quả vào results/."""
import argparse
from collections import Counter
import numpy as np
import torch, torch.nn as nn
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import make_pipeline
from sklearn.svm import LinearSVC

from data import load_splits
from train import run as run_transformer
from utils import set_seed, compute_metrics, save_json, get_device


def tfidf_svm(splits, seed=42):
    train_df, val_df, test_df = splits
    clf = make_pipeline(
        TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True, max_features=200_000),
        LinearSVC(C=1.0, class_weight="balanced", random_state=seed),
    )
    clf.fit(train_df["text_seg"], train_df["label"])
    return {"val_f1": compute_metrics(val_df["label"], clf.predict(val_df["text_seg"]))["f1_macro"],
            "test": compute_metrics(test_df["label"], clf.predict(test_df["text_seg"]))}


class BiLSTM(nn.Module):
    def __init__(self, vocab, n_classes, emb=200, hid=128, dropout=0.4):
        super().__init__()
        self.emb = nn.Embedding(vocab, emb, padding_idx=0)
        self.lstm = nn.LSTM(emb, hid, num_layers=2, batch_first=True, bidirectional=True, dropout=dropout)
        self.drop = nn.Dropout(dropout)
        self.fc = nn.Linear(hid * 2, n_classes)

    def forward(self, x):
        mask = (x != 0).unsqueeze(-1).float()
        h, _ = self.lstm(self.drop(self.emb(x)))
        pooled = (h * mask).sum(1) / mask.sum(1).clamp(min=1)
        return self.fc(self.drop(pooled))


def bilstm(splits, epochs=8, lr=1e-3, batch_size=64, max_len=256, seed=42, patience=2):
    set_seed(seed); device = get_device()
    train_df, val_df, test_df = splits
    cnt = Counter(w for t in train_df["text_seg"] for w in t.lower().split())
    vocab = {w: i + 2 for i, (w, c) in enumerate(cnt.items()) if c >= 2}  # 0=pad, 1=unk
    vocab = {w: i + 2 for i, w in enumerate(vocab)}

    def enc(df):
        ids = [torch.tensor([vocab.get(w, 1) for w in t.lower().split()][:max_len] or [1])
               for t in df["text_seg"]]
        return list(zip(ids, df["label"].tolist()))

    def collate(b):
        x = pad_sequence([i for i, _ in b], batch_first=True)
        return x, torch.tensor([y for _, y in b])

    tr = DataLoader(enc(train_df), batch_size=batch_size, shuffle=True, collate_fn=collate)
    va = DataLoader(enc(val_df), batch_size=batch_size, collate_fn=collate)
    te = DataLoader(enc(test_df), batch_size=batch_size, collate_fn=collate)

    n_classes = int(train_df["label"].nunique())
    model = BiLSTM(len(vocab) + 2, n_classes).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-5)
    loss_fn = nn.CrossEntropyLoss()

    @torch.no_grad()
    def pred(dl):
        model.eval(); ys, ps = [], []
        for x, y in dl:
            ps += model(x.to(device)).argmax(-1).cpu().tolist(); ys += y.tolist()
        return ys, ps

    best, best_state, bad = -1, None, 0
    for ep in range(epochs):
        model.train()
        for x, y in tr:
            opt.zero_grad()
            loss_fn(model(x.to(device)), y.to(device)).backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
        f1 = compute_metrics(*pred(va))["f1_macro"]
        print(f"[BiLSTM {ep+1}/{epochs}] val_f1={f1:.4f}")
        if f1 > best:
            best, bad = f1, 0
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
            if bad >= patience: break
    model.load_state_dict(best_state)
    return {"val_f1": best, "test": compute_metrics(*pred(te))}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="data/news.csv")
    ap.add_argument("--which", nargs="+", default=["svm", "bilstm", "xlmr"],
                    choices=["svm", "bilstm", "xlmr"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[42, 43, 44])
    a = ap.parse_args()

    for seed in a.seeds:
        splits = load_splits(a.csv, seed=seed)
        if "svm" in a.which:
            save_json(tfidf_svm(splits, seed), f"results/svm_s{seed}.json")
        if "bilstm" in a.which:
            save_json(bilstm(splits, seed=seed), f"results/bilstm_s{seed}.json")
        if "xlmr" in a.which:
            r = run_transformer(splits, "xlm-roberta-base", "text", lr=2e-5, batch_size=16,
                                epochs=4, dropout=0.3, seed=seed)
            save_json(r, f"results/xlmr_s{seed}.json")
