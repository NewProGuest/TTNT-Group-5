"""Fine-tune PhoBERT (hoặc XLM-R) và đánh giá."""
import argparse
import numpy as np
import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader
from transformers import AutoTokenizer, get_linear_schedule_with_warmup

from data import load_splits, NewsDataset, make_collate
from model import TransformerClassifier
from utils import set_seed, compute_metrics, save_json, get_device


@torch.no_grad()
def predict(model, loader, device):
    model.eval()
    ys, ps = [], []
    for b in loader:
        logits = model(b["input_ids"].to(device), b["attention_mask"].to(device))
        ps += logits.argmax(-1).cpu().tolist()
        ys += b["labels"].tolist()
    return ys, ps


def run(splits, model_name="vinai/phobert-base", text_col="text_seg", lr=2e-5, batch_size=16,
        epochs=4, dropout=0.3, weight_decay=0.01, max_len=256, patience=2, seed=42,
        eval_test=True, ckpt_path=None, verbose=True):
    """Trả về dict {val_f1, test (nếu eval_test), history}."""
    set_seed(seed)
    device = get_device()
    train_df, val_df, test_df = splits
    n_classes = int(train_df["label"].nunique())

    tok = AutoTokenizer.from_pretrained(model_name)
    collate = make_collate(tok)
    mk = lambda df: NewsDataset(df[text_col], df["label"], tok, max_len)
    train_dl = DataLoader(mk(train_df), batch_size=batch_size, shuffle=True, collate_fn=collate)
    val_dl = DataLoader(mk(val_df), batch_size=batch_size * 2, collate_fn=collate)
    test_dl = DataLoader(mk(test_df), batch_size=batch_size * 2, collate_fn=collate)

    model = TransformerClassifier(model_name, n_classes, dropout).to(device)
    opt = AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    total = len(train_dl) * epochs
    sched = get_linear_schedule_with_warmup(opt, int(0.1 * total), total)

    # trọng số lớp để xử lý mất cân bằng
    counts = np.bincount(train_df["label"], minlength=n_classes)
    weights = torch.tensor(counts.sum() / (n_classes * counts), dtype=torch.float, device=device)
    loss_fn = torch.nn.CrossEntropyLoss(weight=weights)

    use_amp = device == "cuda"
    scaler = torch.amp.GradScaler(enabled=use_amp)
    best_f1, best_state, bad, history = -1.0, None, 0, []

    for ep in range(1, epochs + 1):
        model.train()
        run_loss = 0.0
        for b in train_dl:
            opt.zero_grad()
            with torch.autocast(device_type=device, dtype=torch.float16, enabled=use_amp):
                logits = model(b["input_ids"].to(device), b["attention_mask"].to(device))
                loss = loss_fn(logits, b["labels"].to(device))
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(opt); scaler.update(); sched.step()
            run_loss += loss.item()
        ys, ps = predict(model, val_dl, device)
        m = compute_metrics(ys, ps)
        history.append({"epoch": ep, "train_loss": run_loss / len(train_dl), "val_f1": m["f1_macro"]})
        if verbose:
            print(f"[{ep}/{epochs}] loss={history[-1]['train_loss']:.4f} val_f1={m['f1_macro']:.4f}")
        if m["f1_macro"] > best_f1:
            best_f1, bad = m["f1_macro"], 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
            if bad >= patience:
                break

    result = {"val_f1": best_f1, "history": history}
    if eval_test:
        model.load_state_dict(best_state)
        ys, ps = predict(model, test_dl, device)
        result["test"] = compute_metrics(ys, ps)
    if ckpt_path:
        torch.save(best_state, ckpt_path)
    del model; torch.cuda.empty_cache()
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="data/news.csv")
    ap.add_argument("--text-col", default="text")
    ap.add_argument("--label-col", default="label")
    ap.add_argument("--model", default="vinai/phobert-base")
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--epochs", type=int, default=4)
    ap.add_argument("--dropout", type=float, default=0.3)
    ap.add_argument("--weight-decay", type=float, default=0.01)
    ap.add_argument("--max-len", type=int, default=256)
    ap.add_argument("--patience", type=int, default=2)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--name", default="phobert")
    a = ap.parse_args()

    splits = load_splits(a.csv, a.text_col, a.label_col, seed=a.seed)
    # PhoBERT dùng văn bản đã tách từ; XLM-R dùng văn bản thô
    col = "text" if "xlm" in a.model.lower() else "text_seg"
    res = run(splits, a.model, col, a.lr, a.batch_size, a.epochs, a.dropout, a.weight_decay,
              a.max_len, a.patience, a.seed, ckpt_path=f"models/{a.name}_best.pt")
    save_json(res, f"results/{a.name}.json")
    print("TEST:", {k: v for k, v in res["test"].items() if k != "confusion_matrix"})
