"""Đọc dữ liệu, tách từ tiếng Việt, chia train/val/test, Dataset cho Transformer."""
from pathlib import Path
import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset


def segment(text: str) -> str:
    """PhoBERT yêu cầu văn bản đã tách từ (vd: 'Hà_Nội là thủ_đô')."""
    from underthesea import word_tokenize
    return word_tokenize(text, format="text")


def load_splits(csv_path, text_col="text", label_col="label", seed=42):
    """CSV -> (train_df, val_df, test_df) với cột: text, text_seg, label.

    - Bỏ dòng thiếu và TRÙNG LẶP trước khi chia để tránh rò rỉ train/test.
    - Chia phân tầng 70/15/15.
    - Kết quả tách từ được cache vào <csv>.seg.csv.
    """
    csv_path = Path(csv_path)
    cache = csv_path.with_suffix(".seg.csv")
    if cache.exists():
        df = pd.read_csv(cache)
    else:
        df = pd.read_csv(csv_path)[[text_col, label_col]]
        df.columns = ["text", "label"]
        df = df.dropna()
        df["text"] = df["text"].astype(str).str.strip()
        df = df[df["text"] != ""].drop_duplicates(subset="text").reset_index(drop=True)
        df["text_seg"] = df["text"].map(segment)
        df.to_csv(cache, index=False)

    train_df, tmp = train_test_split(df, test_size=0.30, stratify=df["label"], random_state=seed)
    val_df, test_df = train_test_split(tmp, test_size=0.50, stratify=tmp["label"], random_state=seed)
    return (train_df.reset_index(drop=True), val_df.reset_index(drop=True),
            test_df.reset_index(drop=True))


class NewsDataset(Dataset):
    """Tokenize trước, padding động theo batch (collate_fn)."""

    def __init__(self, texts, labels, tokenizer, max_len=256):
        self.enc = tokenizer(list(texts), truncation=True, max_length=max_len)
        self.labels = list(labels)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, i):
        item = {k: v[i] for k, v in self.enc.items()}
        item["labels"] = self.labels[i]
        return item


def make_collate(tokenizer):
    def collate(batch):
        labels = torch.tensor([b.pop("labels") for b in batch])
        out = tokenizer.pad(batch, return_tensors="pt")
        out["labels"] = labels
        return out
    return collate
