"""Tối ưu siêu tham số PhoBERT bằng Optuna (chọn theo macro-F1 trên tập val)."""
import argparse
import optuna
from data import load_splits
from train import run
from utils import save_json

ap = argparse.ArgumentParser()
ap.add_argument("--csv", default="data/news.csv")
ap.add_argument("--model", default="vinai/phobert-base")
ap.add_argument("--trials", type=int, default=15)
ap.add_argument("--max-len", type=int, default=256)
a = ap.parse_args()

splits = load_splits(a.csv)


def objective(trial):
    params = dict(
        lr=trial.suggest_float("lr", 1e-5, 5e-5, log=True),
        batch_size=trial.suggest_categorical("batch_size", [16, 32]),
        epochs=trial.suggest_int("epochs", 3, 6),
        dropout=trial.suggest_float("dropout", 0.1, 0.5),
        weight_decay=trial.suggest_float("weight_decay", 0.0, 0.1),
    )
    res = run(splits, a.model, "text_seg", max_len=a.max_len, eval_test=False, verbose=False, **params)
    return res["val_f1"]


study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=42))
study.optimize(objective, n_trials=a.trials)
print("Best val F1:", study.best_value, study.best_params)
save_json({"best_val_f1": study.best_value, "best_params": study.best_params,
           "trials": [{"params": t.params, "val_f1": t.value} for t in study.trials]},
          "results/tuning.json")
