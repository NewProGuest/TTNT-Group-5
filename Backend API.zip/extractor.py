"""Tải link bất đồng bộ + bóc tách nội dung bài viết (có chặn SSRF)."""
import asyncio
import ipaddress
import socket
from urllib.parse import urljoin, urlparse

import httpx
import trafilatura

MAX_BYTES = 2_000_000
MAX_REDIRECTS = 3
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; FakeNewsBot/1.0)"}


class ExtractError(Exception):
    pass


async def _assert_public(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ExtractError("URL không hợp lệ.")
    loop = asyncio.get_running_loop()
    try:
        infos = await loop.getaddrinfo(parsed.hostname, None, type=socket.SOCK_STREAM)
    except socket.gaierror:
        raise ExtractError("Không phân giải được tên miền.")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            raise ExtractError("URL trỏ tới địa chỉ nội bộ, bị từ chối.")


async def fetch_article_text(client: httpx.AsyncClient, url: str) -> str:
    current = url
    for _ in range(MAX_REDIRECTS + 1):
        await _assert_public(current)
        try:
            resp = await client.get(current, headers=HEADERS, follow_redirects=False)
        except httpx.HTTPError as e:
            raise ExtractError(f"Không tải được link: {e.__class__.__name__}")
        if resp.is_redirect:
            current = urljoin(current, resp.headers.get("location", ""))
            continue
        break
    else:
        raise ExtractError("Quá nhiều lần chuyển hướng.")

    if resp.status_code >= 400:
        raise ExtractError(f"Trang trả về mã {resp.status_code} (có thể cần đăng nhập).")
    if len(resp.content) > MAX_BYTES:
        raise ExtractError("Trang quá lớn.")

    # trafilatura là CPU-bound -> đẩy sang thread để không chặn event loop
    text = await asyncio.to_thread(
        trafilatura.extract, resp.text, include_comments=False, include_tables=False
    )
    if not text or len(text.split()) < 10:
        raise ExtractError("Không bóc tách được nội dung (trang mạng xã hội thường yêu cầu đăng nhập).")
    return text
