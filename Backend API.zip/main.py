"""Chạy:  uvicorn src.api.main:app --host 0.0.0.0 --port 8000"""
import asyncio
import os
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, HttpUrl, model_validator

from .extractor import ExtractError, fetch_article_text
from .inference import FakeNewsClassifier

MODEL_DIR = os.getenv("MODEL_DIR", "models/onnx")
ONNX_FILE = os.getenv("ONNX_FILE", "model.int8.onnx")
MAX_CONCURRENT_INFER = int(os.getenv("MAX_CONCURRENT_INFER", "2"))


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.clf = FakeNewsClassifier(os.path.join(MODEL_DIR, ONNX_FILE), MODEL_DIR)
    app.state.http = httpx.AsyncClient(timeout=httpx.Timeout(10.0, connect=5.0))
    app.state.sem = asyncio.Semaphore(MAX_CONCURRENT_INFER)  # tránh quá tải CPU
    app.state.clf.predict(["khởi động mô hình"])  # warm-up
    yield
    await app.state.http.aclose()


app = FastAPI(title="Vietnamese Fake News Detection API", lifespan=lifespan)


class PredictRequest(BaseModel):
    text: str | None = Field(None, min_length=10, max_length=20000)
    url: HttpUrl | None = None

    @model_validator(mode="after")
    def need_one(self):
        if bool(self.text) == bool(self.url):
            raise ValueError("Cần cung cấp đúng một trong hai: 'text' hoặc 'url'.")
        return self


class PredictResponse(BaseModel):
    label: str
    confidence: float  # %
    probabilities: dict[str, float]
    source: str  # "text" | "url"
    extracted_text: str | None = None  # đoạn đầu nội dung lấy từ link


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/predict", response_model=PredictResponse)
async def predict(req: PredictRequest):
    source, text = "text", req.text
    if req.url:
        source = "url"
        try:
            text = await fetch_article_text(app.state.http, str(req.url))
        except ExtractError as e:
            raise HTTPException(status_code=422, detail=str(e))

    async with app.state.sem:
        # ONNX Runtime là blocking -> chạy trong thread, event loop vẫn phục vụ request khác
        result = (await asyncio.to_thread(app.state.clf.predict, [text]))[0]

    return PredictResponse(
        **result,
        source=source,
        extracted_text=text[:500] if source == "url" else None,
    )
