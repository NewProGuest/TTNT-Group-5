"""Export PhoBERT đã fine-tune sang ONNX (+ quantize INT8 để chạy CPU nhanh hơn).

Ví dụ:
  python scripts/export_onnx.py --model_dir models/phobert-fakenews --out_dir models/onnx
"""
import argparse
from pathlib import Path

import torch
from onnxruntime.quantization import QuantType, quantize_dynamic
from transformers import AutoModelForSequenceClassification, AutoTokenizer


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_dir", required=True, help="Thư mục checkpoint đã fine-tune")
    ap.add_argument("--out_dir", default="models/onnx")
    ap.add_argument("--max_length", type=int, default=256)
    ap.add_argument("--opset", type=int, default=14)
    args = ap.parse_args()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(args.model_dir)
    model = AutoModelForSequenceClassification.from_pretrained(args.model_dir)
    model.config.return_dict = False
    model.eval()

    dummy = tokenizer(
        ["xin chào các bạn"], return_tensors="pt", padding="max_length",
        max_length=32, truncation=True, return_token_type_ids=False,
    )
    fp32_path = out / "model.onnx"
    torch.onnx.export(
        model,
        (dummy["input_ids"], dummy["attention_mask"]),
        str(fp32_path),
        input_names=["input_ids", "attention_mask"],
        output_names=["logits"],
        dynamic_axes={
            "input_ids": {0: "batch", 1: "seq"},
            "attention_mask": {0: "batch", 1: "seq"},
            "logits": {0: "batch"},
        },
        opset_version=args.opset,
        do_constant_folding=True,
        dynamo=False,  # dùng exporter TorchScript cổ điển, ổn định hơn với dynamic axes
    )
    print(f"[OK] FP32 -> {fp32_path}")

    int8_path = out / "model.int8.onnx"
    quantize_dynamic(str(fp32_path), str(int8_path), weight_type=QuantType.QInt8)
    print(f"[OK] INT8 -> {int8_path}")

    tokenizer.save_pretrained(out)  # API load tokenizer từ cùng thư mục
    print(f"[OK] Tokenizer -> {out}")


if __name__ == "__main__":
    main()
