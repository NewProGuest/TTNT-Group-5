import os
import re

import numpy as np
import onnxruntime as ort
from transformers import AutoTokenizer
from underthesea import word_tokenize

# Phải khớp với id2label lúc fine-tune.
ID2LABEL = {0: "Tin thật", 1: "Tin giả"}


def clean_text(text: str) -> str:
    text = re.sub(r"https?://\S+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


class FakeNewsClassifier:
    def __init__(self, onnx_path: str, tokenizer_dir: str, max_length: int = 256):
        so = ort.SessionOptions()
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        so.intra_op_num_threads = max(1, (os.cpu_count() or 2) // 2)
        self.session = ort.InferenceSession(
            onnx_path, so, providers=["CPUExecutionProvider"]  # thêm CUDAExecutionProvider nếu có GPU
        )
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_dir)
        self.max_length = max_length

    def _preprocess(self, text: str) -> str:
        # PhoBERT yêu cầu văn bản đã tách từ (word-segmented).
        return word_tokenize(clean_text(text), format="text")

    def predict(self, texts: list[str]) -> list[dict]:
        """Blocking – gọi qua asyncio.to_thread từ API."""
        segmented = [self._preprocess(t) for t in texts]
        enc = self.tokenizer(
            segmented, return_tensors="np", padding=True, truncation=True,
            max_length=self.max_length, return_token_type_ids=False,
        )
        logits = self.session.run(
            None,
            {
                "input_ids": enc["input_ids"].astype(np.int64),
                "attention_mask": enc["attention_mask"].astype(np.int64),
            },
        )[0]
        e = np.exp(logits - logits.max(axis=-1, keepdims=True))
        probs = e / e.sum(axis=-1, keepdims=True)

        results = []
        for p in probs:
            idx = int(p.argmax())
            results.append({
                "label": ID2LABEL[idx],
                "confidence": round(float(p[idx]) * 100, 2),
                "probabilities": {ID2LABEL[i]: round(float(v) * 100, 2) for i, v in enumerate(p)},
            })
        return results
